package InterimCodes;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class CharOccurance {
    static void main(String[] args) {

        Scanner sc=new Scanner(System.in);

        Map<Character,Integer> map=new LinkedHashMap<Character,Integer>();
        System.out.println("Enter the String: ");
        String str=sc.nextLine();

        for(int i=0;i<str.length();i++)
        {
            map.put(str.charAt(i),map.getOrDefault(str.charAt(i),0)+1);

        }
           StringBuilder sb=new StringBuilder();
        for(Map.Entry<Character,Integer> entry:map.entrySet())
        {
            String val=""+entry.getValue();
            String k=""+entry.getKey();

            sb.append(val);
            sb.append(k);
        }
        System.out.println(sb.toString());
    }
}
